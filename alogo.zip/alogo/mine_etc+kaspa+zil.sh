#!/bin/sh
./miner --algo etchash --server etc.2miners.com:1010 --user 0x257999Cf9B9d2A952E31a9E475Ef258f27620ef4 --dalgo kheavyhash --dserver kas.2miners.com:2020 --duser kaspa:qrrzeucwfetuty3qserqydw4z4ax9unxd23zwp7tndvg7cs3ls8dvwldeayv5 --zilserver us1-zil.shardpool.io:3333 --ziluser zil14atwug5nmdmaa43y970ss39pxzzehzc4qzgrhe
