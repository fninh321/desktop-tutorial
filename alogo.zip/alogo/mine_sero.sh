#!/bin/sh
./miner --algo sero --server pool2.sero.cash:8808 --user S7gR6CGPX8esKCWBdEjPoshvy9yQDwh6xpec35UFe3gGVEzXpBrXzXCebufTjXXwkFhv8MQ46DKGRyxLPvYVZRDLYU9juwfyd8h6WnGSFEbDRDYFyvtFprPZFkQ66RfeVxZ
