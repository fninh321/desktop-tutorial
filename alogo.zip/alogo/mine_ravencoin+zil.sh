#!/bin/sh
./miner --algo kawpow --server rvn.2miners.com:6060 --user RH2swPipTDBBNxEBdzWuNa4roBu6kFzoTz --zilserver us1-zil.shardpool.io:3333 --ziluser zil14atwug5nmdmaa43y970ss39pxzzehzc4qzgrhe
