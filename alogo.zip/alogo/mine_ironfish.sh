#!/bin/sh
./miner --algo ironfish --server de.ironfish.herominers.com:1145 --user 66e044578b31c6c4c05810b0e5281bdf36138ad41bf6844ba317dc7c506bf9ac+123456789
