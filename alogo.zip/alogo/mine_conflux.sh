#!/bin/sh
./miner --algo octopus --server pool.eu.woolypooly.com:3094 --user cfx:aaketjh9tkj5g2k4zx3kfvb9vkku8nr956n0en4fhe
