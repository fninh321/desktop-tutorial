#!/bin/sh
./miner --algo radiant --server pool.woolypooly.com:3122 --user 1PVyZshLN9TLVAiEdBrfspALhumVSw6VPa
