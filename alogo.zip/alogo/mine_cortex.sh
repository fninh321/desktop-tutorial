#!/bin/sh
./miner --algo cortex --server ctxc.2miners.com:2222 --user 0x321ae4016a6397ee004b3f5f9e6c0a0c1915a05d
