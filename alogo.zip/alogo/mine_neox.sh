#!/bin/sh
./miner --algo kawpow --server neox.2miners.com:4040 --user GJeEoPQPXjxxfkdBzQ23FSGWBN26iB9P9q
