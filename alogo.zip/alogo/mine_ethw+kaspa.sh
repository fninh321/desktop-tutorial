#!/bin/sh
./miner --algo ethash --server ethw.2miners.com:2020 --user 0x00192Fb10dF37c9FB26829eb2CC623cd1BF599E8 --dalgo kheavyhash --dserver kas.2miners.com:2020 --duser kaspa:qrrzeucwfetuty3qserqydw4z4ax9unxd23zwp7tndvg7cs3ls8dvwldeayv5
