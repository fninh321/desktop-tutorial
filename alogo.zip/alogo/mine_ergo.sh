#!/bin/sh
./miner --algo autolykos2 --server erg.2miners.com:8888 --user 9hcksqJGwwYP6hwxzs6fAqfu3Qdi7YdHoK9GrUxpYhNDeFCZrPh
