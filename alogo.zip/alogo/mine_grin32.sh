#!/bin/sh
./miner --algo cuckatoo32 --server grin.2miners.com:3030 --user grin188kxu9vjtq82zrnz03xjtc6up6vsnpgf5s2h9vywsteek0c2958stvxzz9
