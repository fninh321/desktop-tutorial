#!/bin/sh
./miner --algo 144_5 --pers BgoldPoW --server europe.equihash-hub.miningpoolhub.com:20595 --user GGZCAhS59P4GkTg3Er6vEFB2KE6nMty1uKn.rig0 --pass x
