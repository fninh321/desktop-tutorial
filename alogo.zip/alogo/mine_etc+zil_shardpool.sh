#!/bin/sh
./miner --algo etchash --server eu1-zil.shardpool.io:3333 --user 0x321ae4016a6397ee004b3f5f9e6c0a0c1915a05d --pass zil14atwug5nmdmaa43y970ss39pxzzehzc4qzgrhe@etc.2miners.com:1010
